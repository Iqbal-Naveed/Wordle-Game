#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <ctime>

#define LISTSIZE 1000

#define EXACT 2
#define CLOSE 1
#define WRONG 0

#define GREEN "\e[38;2;255;255;255;1m\e[48;2;106;170;100;1m"
#define YELLOW "\e[38;2;255;255;255;1m\e[48;2;201;180;88;1m"
#define RED "\e[38;2;255;255;255;1m\e[48;2;220;20;60;1m"
#define RESET "\e[0;39m"

using namespace std;

class Wordle
{
private:
    int wordsize;
    string file_name;
    ifstream my_file;
    string options[LISTSIZE];
    bool won;
    string choice;

public:
    Wordle() : wordsize(0), file_name(""), won(false) {}

    void selectWord()
    {
        while (wordsize < 5 || wordsize > 8)
        {
            cout << "Enter word size (5-8): ";
            cin >> wordsize;
        }

        file_name = to_string(wordsize) + ".txt";
        my_file.open(file_name);
        if (!my_file.is_open())
        {
            cout << "Could not open file!" << endl;
            exit(1);
        }

        string word;
        int count = 0;
        while (my_file >> word && count < LISTSIZE)
        {
            options[count] = word;
            count++;
        }

        srand(time(NULL));
        choice = options[rand() % count];
    }

    bool checkGuess(const string &guess)
    {
        int score = 0;
        int status[LISTSIZE] = {WRONG};

        for (int i = 0; i < wordsize; i++)
        {
            for (int j = 0; j < wordsize; j++)
            {
                if (guess[i] == choice[j])
                {
                    if (i == j)
                    {
                        status[i] = EXACT;
                        break;
                    }
                    status[i] = CLOSE;
                }
            }
            score += status[i];
        }

        printWord(guess, status);

        if (score == 2 * wordsize)
        {
            won = true;
        }

        return won;
    }

    void printResult(bool won)
    {
        if (won)
        {
            cout << "HURRAH...YOU WON!!" << endl;
        }
        else
        {
            cout << "Correct Word: " << GREEN << choice << RESET << endl;
            cout << "BETTER LUCK NEXT TIME" << endl;
        }
    }

    static void printWord(const string &guess, const int *status)
    {
        for (int i = 0; i < guess.length(); i++)
        {
            if (status[i] == EXACT)
            {
                cout << GREEN << " " << guess[i];
            }
            else if (status[i] == CLOSE)
            {
                cout << YELLOW << " " << guess[i];
            }
            else if (status[i] == WRONG)
            {
                cout << RED << " " << guess[i];
            }
        }
        cout << RESET << endl;
    }

    int getNoGuesses() const
    {
        return wordsize + 1;
    }

    int getWordSize() const
    {
        return wordsize;
    }

    bool getWon() const
    {
        return won;
    }

    string getChoice() const
    {
        return choice;
    }
};

class Person
{
protected:
    string name;
    int guesses;

public:
    Person(const string n)
    {
        name = n;
        guesses = 0;
    }

    Person()
    {
        cout << "Enter your name: ";
        cin >> name;
    }

    string get_name() { return name; }
    virtual void play() = 0;
};

class SinglePlayer : public Person
{
public:
    Wordle wordle;
    SinglePlayer(const string n) : Person(n) {}

    void play() override
    {
        wordle.selectWord();
        cout << "Let's Begin " << name << endl;
        cout << "You have " << wordle.getNoGuesses() << " guesses" << endl;

        for (int i = 0; i < wordle.getNoGuesses(); i++)
        {
            string guess = "";
            while (guess.length() != wordle.getWordSize())
            {
                cout << "Enter a " << wordle.getWordSize() << " letter word: ";
                cin >> guess;
            }
            guesses++;

            bool won = wordle.checkGuess(guess);
            if (won)
            {
                cout << "You guessed it in: " << guesses << " attempts" << endl;
                break;
            }
        }

        wordle.printResult(wordle.getWon());
    }
};

class MultiPlayer : public Person
{
public:
    Wordle wordle;
    MultiPlayer(const string n) : Person(n) {}

    void play() override
    {

        cout << "Let's Begin Multiplayer" << endl;

        wordle.selectWord();
        cout << "You have " << wordle.getNoGuesses() << " guesses" << endl;

        for (int i = 0; i < wordle.getNoGuesses(); i++)
        {
            string guess;
            while (guess.length() != wordle.getWordSize())
            {
                cout << "Enter a " << wordle.getWordSize() << " letter word: ";
                cin >> guess;
            }
            guesses++;

            bool won = wordle.checkGuess(guess);
            if (won)
            {
                cout << "You guessed it in: " << guesses << " attempts" << endl;
                break;
            }
        }
    }

    int getGuesses()
    {
        return guesses;
    }
};

int main()
{
    cout << GREEN "This is Wordle 50" << RESET << endl;
    cout << endl
         << RED "Red Color" << RESET " Shows That the letter is not in the word" << endl;
    cout << YELLOW "Yellow Color" << RESET " Shows That the letter is in incorrect position" << endl;
    cout << GREEN "Green Color" << RESET << " Shows That the letter is in correct position" << endl
         << endl;

    char choice;
    cout << "Choose game mode (S for Singleplayer, M for Multiplayer): ";
    cin >> choice;

    if (choice == 'S' || choice == 's')
    {
        string name;
        cout << "Enter your name: ";
        cin.ignore();
        getline(cin, name);
        SinglePlayer singlePlayer(name);
        singlePlayer.play();
    }
    else if (choice == 'M' || choice == 'm')
    {
        string player1Name;
        cout << "Enter the name of the first player: ";
        cin.ignore();
        getline(cin, player1Name);
        MultiPlayer player1(player1Name);
        player1.play();

        string player2Name;
        cout << "Enter the name of the second player: ";
        cin.ignore();
        getline(cin, player2Name);
        MultiPlayer player2(player2Name);
        player2.play();

        int player1Score = player1.getGuesses();
        int player2Score = player2.getGuesses();

        if (player1.wordle.getWon() && !player2.wordle.getWon())
        {
            cout << player1.get_name() << " wins!" << endl;
            cout << "Correct Word for " << player2.get_name() << ": " << GREEN << player2.wordle.getChoice() << RESET << endl;
        }
        else if (!player1.wordle.getWon() && player2.wordle.getWon())
        {
            cout << player2.get_name() << " wins!" << endl;
            cout << "Correct Word for " << player1.get_name() << ": " << GREEN << player1.wordle.getChoice() << RESET << endl;
        }
        else if (player1.wordle.getWon() && player2.wordle.getWon())
        {
            if (player1Score < player2Score)
            {
                cout << player1.get_name() << " wins!" << endl;
            }
            else if (player1Score > player2Score)
            {
                cout << player2.get_name() << " wins!" << endl;
            }
            else
            {
                cout << "It's a tie!" << endl;
            }
        }
        else
        {
            cout << "Neither player guessed the correct word." << endl;
            cout << "Correct Word for " << player1.get_name() << ": " << GREEN << player1.wordle.getChoice() << RESET << endl;
            cout << "Correct Word for " << player2.get_name() << ": " << GREEN << player2.wordle.getChoice() << RESET << endl;
        }
    }
    else
    {
        cout << "Invalid choice!" << endl;
    }

    return 0;
}